const help = (prefix) => {
	return `

📌 Prefix:  *「${prefix} 」*
🔎 Status: *「 Online 」*



╭ ─ ─═「 *𝗞𝗘𝗡 𝗕𝗢𝗧 * 」
│
│bot feito por KEN 🤠🤙
│data de criação :13 de janeiro de 2021
│
│design : KEN
│mais informações digite *${prefix}dono*
│
├ ─ ─ ─ ─ ─ ─ ─
│ 𝙆𝙀𝙉 𝘿𝙊𝙈𝙄𝙉𝘼 🤏😎
╰ ─ ─ ─ ─ ─ ─ ─ ─ 


╭─────⊣〘 𝗙𝗜𝗚𝗨𝗥𝗜𝗡𝗛𝗔 〙
│    
┝➥ *${prefix}sticker* ou *${prefix}stiker*
│➛ converter imagem/gif/vídeo em adesivo
│
┝➥ *${prefix}sticker nobg* ou *${prefix}stiker nobg*
│➛ converter imagem em figurinha removendo o fundo
│
┝➥ *${prefix}toimg*
│➛ converter figurinha em imagem
│
┝➥ *${prefix}tsticker* ou *${prefix}tstiker*
│➛ converter texto em adesivo
│
╭─────⊣〘 𝗠𝗘𝗠𝗘 〙
│      
┝➥ *${prefix}meme*
│➛ mandar imagens aleatórias de meme [inglês]
│
┝➥ *${prefix}memeindo*
│➛ mandar imagens aleatórias de meme [indo]
│
╭─────⊣〘 𝗢𝗨𝗧𝗥𝗢𝗦 〙
│
┝➥ *${prefix}gtts*
│➛ converter texto em fala/áudio
│➛exemplo: *${prefix}gtts ja On2-chan*\n
│
┝➥ *${prefix}loli1*
│➛ mandar imagens aleatórias de loli
│
┝➥ *${prefix}nsfwloli*
│➛ mandar imagens aleatórias de nsfw loli
➸ uso : basta enviar o comando\n
│
┝➥ *${prefix}url2img*
│➛ tirar screenshots da web
│➛exemplo: *${prefix}url2img [tipe] [url]*\n
│
┝➥ *${prefix}simi*
│➛ responder sua mensagem por simi
│➛uso : *${prefix}simi sua mensagem*\n
│
┝➥ *${prefix}ocr*
│➛ pegar o texto da foto e lhe enviar
│
┝➥ *${prefix}wait*
│➛ pesquisar sobre o anime por imagem [ Que anime é este/que ]
│
┝➥ *${prefix}setprefix*
│➛ alterar o prefixo do bot
│➛exemplo : *${prefix}setprefix ?*
│
│⚠️ Usado somente pelo proprietário do bot\n
│
╭─────⊣〘 𝗚𝗥𝗨𝗣𝗢 〙
│
┝➥ *${prefix}linkgroup*
│➛ enviar o link do grupo
│
┝➥ *${prefix}marcar*
│➛ marcar todos os membros do grupo, incluindo administradores
│
│⚠️ Você precisa ser administrador do grupo\n
│
┝➥ *${prefix}simih*
│
│➛ ativar o modo simi no grupo 
│➛ *${prefix}simih 1*  ↲
│
│➛ desativar o modo simih 
│➛ *${prefix}simih 0* 
│
│ ⚠️ Você precisa ser administrador do grupo\n
│
┝➥ *${prefix}add*
│➛ adicionar membro ao grupo
│➛ *${prefix}add 5511xxxxx*\n
│
│ ⚠️ o bot precisa ser admin!\n
│
┝➥ *${prefix}kick*
│➛ remover membros do grupo
│➛ *${prefix}kick e o @da pessoa*\n
│
│ ⚠️ Você precisa ser admin e o bot também
│
┝➥ *${prefix}promote*
│➛ tornar membro do grupo um administrador
│➛ *${prefix}promote e o @da pessoa*\n
│
│ ⚠️ Você precisa ser admin e o bot também
│
┝➥ *${prefix}demote*
│➛ tornar o administrador um membro comum
│➛ *${prefix}demote e o @da pessoa*\n
│
│ ⚠️ Você precisa ser admin e o bot também


╭─────⊣〘 𝗠𝗘𝗡𝗨 𝗚𝗘𝗥𝗔𝗟 〙
│
├➤ *${prefix}help1* ♔
│
╰ ─ ─ ─ ─ ─ ─ ─ ─`
}

exports.help = help

























